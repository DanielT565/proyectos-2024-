//Si funciona no lo muevan////Si funciona no lo muevan//
import React from "react";
import "/src/view/css/loading.css";
import "/src/view/css/styles.css";
import logo from "/src/image/logo.png";
import HomeIcon from "@mui/icons-material/Home";
import AssignmentIndIcon from "@mui/icons-material/AssignmentInd";
import LeaderboardIcon from "@mui/icons-material/Leaderboard";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import { Buscador } from "/src/view/section/buscador.jsx";
import { Accounts } from "/src/view/section/noti_men_config.jsx";
import { Button } from "@mui/material";

import { Route, Routes } from "react-router-dom";
import { Icon } from "atomize";

//Los Lazy son para llamar con la exportacion en defecto a los demas paginas
const LazyInicio = React.lazy(() => import("./inicio.jsx"));
const LazyProyecto = React.lazy(() => import("./proyecto.jsx"));
const LazySeguimiento = React.lazy(() => import("./seguimiento.jsx"));
const LazyGrafica1 = React.lazy(() => import("./grafica1.jsx"));
const LazyGrafica2 = React.lazy(() => import("./grafica2.jsx"));
const LazyPerfil = React.lazy(() => import("./perfil.jsx"));
const LazyClientes = React.lazy(() => import("./anadirclientes.jsx"));

/*
 *Estructura del menu donde se mostrara la informacion de cada
 pagina sin repetir el codigo de menu, buscador y los iconos
 de notificacion, mensaje y perfil 
 */
export function Estruct() {
  return (
    <div className="container-center-horizontal">
      <div className="dashboard-graphics screen">
        <div className="fondo">
          <div className="barmenu">
            <Menus />
          </div>
          <ul>
            <div className="unionup">
              <Buscador />
              <Accounts />
            </div>
            <div className="areatrabajo">
              <div>
                {/*
                *Estos routes son para mostrar la informacion contenida en 
                cada pagina, se utiliza esta vez el routes y no el router
                porque no puede aver un router dentro del router
                si es necesario tener el menu en las siguientes paginas
                añadir la el route correspondiente a la pagina en cuestion
                 */}
                <Routes>
                  <Route
                    path="/"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyInicio />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/proyecto"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyProyecto />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/seguimiento"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazySeguimiento />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/grafica1"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyGrafica1 />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/grafica2"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyGrafica2 />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/perfil"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyPerfil />
                      </React.Suspense>
                    }
                  />
                  <Route
                    path="/anadirclientes"
                    element={
                      <React.Suspense
                        fallback={
                          <Icon
                            color="#641E16"
                            name="Loading"
                            className="loading"
                          />
                        }
                      >
                        <LazyClientes />
                      </React.Suspense>
                    }
                  />
                </Routes>
              </div>
            </div>
          </ul>
        </div>
      </div>
    </div>
  );
}

//juntar todos los botones para mandarlos a importar a otra clase y con esto se reduce el codigo en import
function Menus() {
  return (
    <div className="barmenu">
      <img src={logo} alt="logo" className="logo" />
      <MInicio />
      <MProyecto />
      <MSeguimiento />
      <MGrafica1 />
      <MGrafica2 />
      <MClientes />
    </div>
  );
}
//Apartir de aqui son funciones por cada boton
///Inicio
function MInicio() {
  return (
    <Button
      color="error"
      className="btninicio"
      startIcon={<HomeIcon />}
      href="/"
    >
      Inicio
    </Button>
  );
}
//Proyecto
function MProyecto() {
  return (
    <Button
      color="error"
      className="btnmenu"
      startIcon={<AssignmentIndIcon />}
      href="/proyecto"
    >
      Proyecto
    </Button>
  );
}
//Seguimiento
function MSeguimiento() {
  return (
    <Button
      color="error"
      className="btnmenu"
      startIcon={<AssignmentIndIcon />}
      href="/seguimiento"
    >
      Seguimiento
    </Button>
  );
}
//Grafica 1
function MGrafica1() {
  return (
    <Button
      color="error"
      className="btnmenu"
      startIcon={<LeaderboardIcon />}
      href="/grafica1"
    >
      Grafica 1
    </Button>
  );
}
//Grafica 2
function MGrafica2() {
  return (
    <Button
      color="error"
      className="btnmenu"
      startIcon={<LeaderboardIcon />}
      href="/grafica2"
    >
      Grafica 2
    </Button>
  );
}

//Añadir Cliente
function MClientes() {
  return (
    <Button
      color="error"
      className="btnmenu"
      startIcon={<PersonAddIcon />}
      href="/anadirclientes"
    >
      Clientes
    </Button>
  );
}
