//Si funciona no lo muevan//
import { Avatar } from "@mui/material";
import { Icon } from "atomize";
import { Typography } from "@mui/material";
import "/src/view/css/perfil.css";
import { Button } from "@mui/material";

function DashPerfil() {
  return <Areatrabajo />;
}

//Seccion de Area de Trabajo Titulo Y Texto
function Areatrabajo() {
  return (
    <div>
      <div className="unionperf">
        <Avatar className="img" sx={{ width: 150, height: 150 }}>
          <Icon name="UserSolid" />
        </Avatar>
        <Typography className="txtn" variant="h3">
          Nombre/s
        </Typography>
        <Typography className="txtn" variant="h3">
          Apellidos
        </Typography>
      </div>
      <br />
      <div className="unionperf">
        <div>
          <Typography variant="h4">Numero Telefonico</Typography>
          <br />
          <Typography variant="h5">Numero Telefonico</Typography>
        </div>

        <div>
          <Typography variant="h4">Correo Electronico</Typography>
          <br />
          <Typography variant="h5">Numero Telefonico</Typography>
        </div>
      </div>
      <br />
      <Typography variant="h4">Informacion Personal</Typography>
      <br />
      <Typography variant="h5">Numero Telefonico</Typography>
      <br />
      <Button
        onClick={() => (window.location.href = "/")}
        variant="contained"
        color="error"
        className="btningresar"
      >
        Guardar Cambios
      </Button>
    </div>
  );
}

export default DashPerfil;
