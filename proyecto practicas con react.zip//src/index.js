//Si funciona no le muevan
import React from "react";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
//Estas importaciones de Router son para rediriguir a las paginas correspondientes del menu
//Para saber mas busquen en la guia de react router dom
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Estruct } from "/src/view/pages/menu.js";
import { DashLogin } from "/src/view/pages/login.js";
import { DashRecover } from "/src/view/pages/recordar.jsx";
import "/src/view/css/log_recover.css";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
//Se manda a llamar la funcion pages para que muestre el contenido de JS y JSX
try {
  root.render(
    <StrictMode>
      <Pages />
    </StrictMode>
  );

  function Pages() {
    return (
      <div>
        {/* Elemento Router para llamar a las paginas */}
        <Router>
          <Routes>
            {/* Existen 2 path de / esto para que el menu sea el principal
            y lo que es el inicio.jsx sea el inicial dentro del menu */}
            <Route path="/" element={<Estruct />}>
              <Route path="/" />
              <Route path="/proyecto" />
              <Route path="/seguimiento" />
              <Route path="/grafica1" />
              <Route path="/grafica2" />
              <Route path="/perfil" />
              <Route path="/anadirclientes" />
            </Route>
            <Route path="/login" element={<DashLogin />} />
            <Route path="/recordar" element={<DashRecover />} />
          </Routes>
        </Router>
      </div>
    );
  }
} catch (error) {
  console.log(error);
}
